﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            txtRaio = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Font = new Font("Segoe UI", 13F);
            lblRaio.Location = new Point(136, 62);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(47, 25);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 13F);
            lblAltura.Location = new Point(136, 108);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Font = new Font("Segoe UI", 13F);
            lblVolume.Location = new Point(136, 160);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(72, 25);
            lblVolume.TabIndex = 2;
            lblVolume.Text = "Volume";
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(342, 108);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(184, 23);
            txtAltura.TabIndex = 3;
            txtAltura.Validating += txtAltura_Validating;
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(342, 160);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(184, 23);
            txtVolume.TabIndex = 4;
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(342, 62);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(184, 23);
            txtRaio.TabIndex = 5;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 13F);
            btnCalcular.Location = new Point(136, 295);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(164, 64);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 13F);
            btnLimpar.Location = new Point(342, 295);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(164, 63);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnFechar
            // 
            btnFechar.Font = new Font("Segoe UI", 13F);
            btnFechar.Location = new Point(546, 295);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(164, 64);
            btnFechar.TabIndex = 8;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnFechar);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtRaio);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private TextBox txtRaio;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnFechar;
    }
}
