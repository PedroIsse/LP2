namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio;
        double altura;
        double volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio)) // Verifica se houve algum problema na convers�o de strings para double
            {
                MessageBox.Show("Raio inv�lido!");
                txtRaio.Focus(); // Foca na textbox do raio para o valor ser inserido novamente
            }
            else
            {
                if (raio <= 0) // Verifica se o valor de raio � menor ou igual a zero
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();
                }
            }
        }

        private void txtAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura)) // Verifica se houve algum problema na convers�o de strings para double
            {
                MessageBox.Show("Altura inv�lida!");
                e.Cancel = true; // Cancela a a��o que o usu�rio fez (Seja de passar para outra textbox, apertar um bot�o, o que escreveu, etc.)
            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura; // F�rmula do volume do cilindro
            txtVolume.Text = volume.ToString("N2"); // Escreve o resultado na TextBox com 2 casas decimais
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear(); // Limpa TextBox
            txtRaio.Clear();
            txtVolume.Clear();

            txtRaio.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close(); // Fecha programa
        }
    }
}
