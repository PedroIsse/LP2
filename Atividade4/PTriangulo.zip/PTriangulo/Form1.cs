namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("N�mero Inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("N�mero Inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("N�mero Inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLadoC.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (ladoA > Math.Abs(ladoB - ladoC) && ladoA < ladoB + ladoC && ladoB > Math.Abs(ladoA - ladoC) && ladoB < ladoA + ladoC && ladoC > Math.Abs(ladoA - ladoB) && ladoC < ladoA + ladoC)
            {
                if (ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                    MessageBox.Show("� um tri�ngulo escaleno!", "Tri�ngulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (ladoA == ladoB && ladoB == ladoC && ladoA == ladoC)
                    MessageBox.Show("� um tri�ngulo equil�tero!", "Tri�ngulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("� um tri�ngulo is�celes!", "Tri�ngulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("N�o � poss�vel formar um tri�ngulo com essas medidas!", "Falha!", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
        }
    }
}
