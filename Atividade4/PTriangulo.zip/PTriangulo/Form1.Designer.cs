﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            lblLadoC = new Label();
            lblLadoB = new Label();
            txtLadoA = new TextBox();
            txtLadoC = new TextBox();
            txtLadoB = new TextBox();
            btnVerificar = new Button();
            btnSair = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Font = new Font("Segoe UI", 13F);
            lblLadoA.Location = new Point(10, 12);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(68, 25);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Lado A";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Font = new Font("Segoe UI", 13F);
            lblLadoC.Location = new Point(9, 99);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(67, 25);
            lblLadoC.TabIndex = 1;
            lblLadoC.Text = "Lado C";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Font = new Font("Segoe UI", 13F);
            lblLadoB.Location = new Point(10, 57);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(66, 25);
            lblLadoB.TabIndex = 2;
            lblLadoB.Text = "Lado B";
            // 
            // txtLadoA
            // 
            txtLadoA.Location = new Point(104, 12);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(100, 23);
            txtLadoA.TabIndex = 3;
            txtLadoA.Validated += txtLadoA_Validated;
            // 
            // txtLadoC
            // 
            txtLadoC.Location = new Point(104, 99);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(100, 23);
            txtLadoC.TabIndex = 4;
            txtLadoC.Validated += txtLadoC_Validated;
            // 
            // txtLadoB
            // 
            txtLadoB.Location = new Point(104, 57);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(100, 23);
            txtLadoB.TabIndex = 5;
            txtLadoB.Validated += txtLadoB_Validated;
            // 
            // btnVerificar
            // 
            btnVerificar.Font = new Font("Segoe UI", 13F);
            btnVerificar.Location = new Point(235, 11);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(156, 114);
            btnVerificar.TabIndex = 6;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 13F);
            btnSair.Location = new Point(559, 10);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(156, 114);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 13F);
            btnLimpar.Location = new Point(397, 11);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(156, 114);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(722, 139);
            Controls.Add(btnLimpar);
            Controls.Add(btnSair);
            Controls.Add(btnVerificar);
            Controls.Add(txtLadoB);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoA);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoC;
        private Label lblLadoB;
        private TextBox txtLadoA;
        private TextBox txtLadoC;
        private TextBox txtLadoB;
        private Button btnVerificar;
        private Button btnSair;
        private Button btnLimpar;
    }
}
