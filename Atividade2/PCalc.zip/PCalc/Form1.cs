namespace PCalc
{
    public partial class Form1 : Form
    {

        double num1, num2, resultado; // Vari�veis globais
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out num1)) // Verifica se a convers�o para double funcionou 
            {
                // MessageBox.Show("N�mero Inv�lido!");
                errorProvider1.SetError(txtNum1, "N�mero 1 inv�lido!"); // Mostra o erro e espec�fica o motivo (program�vel)
                txtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNum1, ""); // Retira quando o valor for valido
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                num2 = Convert.ToDouble(txtNum2.Text);
            }
            catch (Exception ex)
            {
                // MessageBox.Show("N�mero inv�lido!\n" + ex.Message); // Se ocorreu erro, avisa o usu�rio e mostra a mensagem de erro
                errorProvider2.SetError(txtNum2, "N�mero 2 inv�lido!");
                Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Divis�o por zero n�o existe!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error); // TEXTO, T�TULO, BOT�O, ICONE 
                txtNum2.Text = "";
                txtNum2.Focus();
            }
            else
            {
                resultado = num1 / num2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear(); // Limpa os campos 
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Voc� deseja sair mesmo?", "Sa�da", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) // Se usu�rio escolher sim 
            {
                Close(); // Fechar programa
            }
        }
    }
}
