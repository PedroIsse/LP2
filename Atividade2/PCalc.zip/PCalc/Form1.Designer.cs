﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblNum1 = new Label();
            lblNum2 = new Label();
            lblResultado = new Label();
            btnLimpar = new Button();
            btnSair = new Button();
            btnAdd = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            txtResultado = new TextBox();
            txtNum1 = new TextBox();
            txtNum2 = new TextBox();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Font = new Font("Segoe UI", 15F);
            lblNum1.Location = new Point(12, 9);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(100, 28);
            lblNum1.TabIndex = 0;
            lblNum1.Text = "Número 1";
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Font = new Font("Segoe UI", 15F);
            lblNum2.Location = new Point(12, 59);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(100, 28);
            lblNum2.TabIndex = 1;
            lblNum2.Text = "Número 2";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI", 15F);
            lblResultado.Location = new Point(12, 109);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(98, 28);
            lblResultado.TabIndex = 2;
            lblResultado.Text = "Resultado";
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 15F);
            btnLimpar.Location = new Point(452, 14);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(336, 48);
            btnLimpar.TabIndex = 3;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 15F);
            btnSair.Location = new Point(452, 89);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(336, 48);
            btnSair.TabIndex = 4;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 20F);
            btnAdd.Location = new Point(12, 183);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(167, 94);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Font = new Font("Segoe UI", 20F);
            btnSub.Location = new Point(185, 183);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(167, 94);
            btnSub.TabIndex = 6;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMult
            // 
            btnMult.Font = new Font("Segoe UI", 20F);
            btnMult.Location = new Point(358, 183);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(167, 94);
            btnMult.TabIndex = 7;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 20F);
            btnDiv.Location = new Point(531, 183);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(167, 94);
            btnDiv.TabIndex = 8;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(116, 114);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(297, 23);
            txtResultado.TabIndex = 9;
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(118, 14);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(295, 23);
            txtNum1.TabIndex = 10;
            txtNum1.Validated += txtNum1_Validated;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(118, 64);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(295, 23);
            txtNum2.TabIndex = 11;
            txtNum2.Validated += txtNum2_Validated;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 302);
            Controls.Add(txtNum2);
            Controls.Add(txtNum1);
            Controls.Add(txtResultado);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(lblResultado);
            Controls.Add(lblNum2);
            Controls.Add(lblNum1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNum1;
        private Label lblNum2;
        private Label lblResultado;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMult;
        private Button btnDiv;
        private TextBox txtResultado;
        private TextBox txtNum1;
        private TextBox txtNum2;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
