﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            char[] stringona = rchtxtFrase.Text.ToCharArray();
            int contWhiteSpace = 0;

            for (int i = 0; i < stringona.Length; i++)
            {
                if (char.IsWhiteSpace(stringona[i]))
                {
                    contWhiteSpace++;
                }
            }

            MessageBox.Show($"Número de espaços em branco: {contWhiteSpace}", "Número espaços em branco", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLetrasR_Click(object sender, EventArgs e)
        {
            char[] stringona = rchtxtFrase.Text.ToCharArray();
            int contR = 0;

            for (int i = 0; i < stringona.Length; i++)
            {
                if (stringona[i] == 'R')
                {
                    contR++;
                }
            }

            MessageBox.Show($"Número de letras R: {contR}", "Número de letras R", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnParesLetras_Click(object sender, EventArgs e)
        {
            char[] stringona = rchtxtFrase.Text.ToCharArray();
            int contPares = 0;

            for (int i = 0; i < stringona.Length - 1; i++)
            {
                    if (string.Compare(stringona[i].ToString(), stringona[i + 1].ToString()) == 0)
                    {
                        contPares++;
                    }
            }

            MessageBox.Show($"Número de letras pares: {contPares}", "Número de letras pares", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
