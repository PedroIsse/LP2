﻿namespace Ploops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblMatricula = new Label();
            lblProducao = new Label();
            lblSalario = new Label();
            lblGratificacao = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            btnCalc = new Button();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(12, 14);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(12, 46);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 1;
            lblMatricula.Text = "Matrícula";
            // 
            // lblProducao
            // 
            lblProducao.AutoSize = true;
            lblProducao.Location = new Point(12, 75);
            lblProducao.Name = "lblProducao";
            lblProducao.Size = new Size(58, 15);
            lblProducao.TabIndex = 2;
            lblProducao.Text = "Produção";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(12, 107);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(42, 15);
            lblSalario.TabIndex = 3;
            lblSalario.Text = "Salário";
            // 
            // lblGratificacao
            // 
            lblGratificacao.AutoSize = true;
            lblGratificacao.Location = new Point(12, 136);
            lblGratificacao.Name = "lblGratificacao";
            lblGratificacao.Size = new Size(70, 15);
            lblGratificacao.TabIndex = 4;
            lblGratificacao.Text = "Gratificação";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(58, 6);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(130, 23);
            txtNome.TabIndex = 5;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(75, 38);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(113, 23);
            txtMatricula.TabIndex = 6;
            // 
            // txtProducao
            // 
            txtProducao.Location = new Point(75, 67);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(113, 23);
            txtProducao.TabIndex = 7;
            txtProducao.Validating += txtProducao_Validating;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(58, 99);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(130, 23);
            txtSalario.TabIndex = 8;
            txtSalario.Validating += txtSalario_Validating;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Location = new Point(88, 128);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(100, 23);
            txtGratificacao.TabIndex = 9;
            txtGratificacao.TextChanged += txtGratificacao_TextChanged;
            // 
            // btnCalc
            // 
            btnCalc.Location = new Point(12, 169);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(176, 80);
            btnCalc.TabIndex = 10;
            btnCalc.Text = "Calcular salário bruto";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += btnCalc_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(208, 266);
            Controls.Add(btnCalc);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(lblGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lblProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lblNome);
            Name = "frmExercicio4";
            Text = "Exercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblMatricula;
        private Label lblProducao;
        private Label lblSalario;
        private Label lblGratificacao;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private Button btnCalc;
    }
}