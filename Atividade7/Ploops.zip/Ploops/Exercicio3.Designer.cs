﻿namespace Ploops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPalindromos = new Button();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            SuspendLayout();
            // 
            // btnPalindromos
            // 
            btnPalindromos.Location = new Point(12, 91);
            btnPalindromos.Name = "btnPalindromos";
            btnPalindromos.Size = new Size(340, 52);
            btnPalindromos.TabIndex = 0;
            btnPalindromos.Text = "São palíndromos?";
            btnPalindromos.UseVisualStyleBackColor = true;
            btnPalindromos.Click += btnPalindromos_Click;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(72, 6);
            txtPalavra1.MaxLength = 50;
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(280, 23);
            txtPalavra1.TabIndex = 1;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(72, 50);
            txtPalavra2.MaxLength = 50;
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(280, 23);
            txtPalavra2.TabIndex = 2;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(12, 9);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(54, 15);
            lblPalavra1.TabIndex = 3;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(12, 50);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(54, 15);
            lblPalavra2.TabIndex = 4;
            lblPalavra2.Text = "Palavra 2";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(370, 161);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(btnPalindromos);
            Name = "frmExercicio3";
            Text = "Exercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPalindromos;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Label lblPalavra1;
        private Label lblPalavra2;
    }
}