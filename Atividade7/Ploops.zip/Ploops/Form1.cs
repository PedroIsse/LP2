namespace Ploops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sa�da", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio1 frmExercicio1 = new frmExercicio1();
            frmExercicio1.Show();
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 frmExercicio2 = new frmExercicio2();
            frmExercicio2.Show();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 frmExercicio3 = new frmExercicio3();
            frmExercicio3.Show();
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmExercicio4 = new frmExercicio4();
            frmExercicio4.Show();
        }
    }
}
