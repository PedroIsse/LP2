﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        int n;

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            double H = 0;

            for (int i = 1; i <= n; i++)
            {
                H += 1 / (double)i;
            }

            MessageBox.Show($"H resultou em {H}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtN_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtN.Text, out n))
            {
                MessageBox.Show("Número Inválido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtN.Clear();
                txtN.Focus();
            }
        }
    }
}
