﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        int D=0, B=0, C=0, producao;
        double salario, gratificacao;

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if(producao >= 150)
                B = C = D = 1;
            else if(producao < 150 && producao >= 120)
                B = C = 1;
            else if(producao < 120 && producao >= 100)
                B = 1;

            double salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if(salarioBruto > 7000.0)
            {
                if (!(B == 1 && C == 1 && D == 1))
                    salarioBruto = 7000.0;
            }
        }

        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Produção inválida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtProducao.Clear();
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Salário inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSalario.Clear();
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtGratificacao.Clear();
                txtGratificacao.Focus();
            }
        }
    }
}
