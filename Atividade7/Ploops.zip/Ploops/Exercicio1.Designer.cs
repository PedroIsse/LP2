﻿namespace Ploops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnEspacoBranco = new Button();
            btnLetrasR = new Button();
            btnParesLetras = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(12, 12);
            rchtxtFrase.MaxLength = 100;
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(210, 426);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnEspacoBranco
            // 
            btnEspacoBranco.Location = new Point(237, 12);
            btnEspacoBranco.Name = "btnEspacoBranco";
            btnEspacoBranco.Size = new Size(233, 76);
            btnEspacoBranco.TabIndex = 1;
            btnEspacoBranco.Text = "Número espaço em brancos";
            btnEspacoBranco.UseVisualStyleBackColor = true;
            btnEspacoBranco.Click += btnEspacoBranco_Click;
            // 
            // btnLetrasR
            // 
            btnLetrasR.Location = new Point(237, 186);
            btnLetrasR.Name = "btnLetrasR";
            btnLetrasR.Size = new Size(233, 76);
            btnLetrasR.TabIndex = 2;
            btnLetrasR.Text = "Número de letras R";
            btnLetrasR.UseVisualStyleBackColor = true;
            btnLetrasR.Click += btnLetrasR_Click;
            // 
            // btnParesLetras
            // 
            btnParesLetras.Location = new Point(237, 362);
            btnParesLetras.Name = "btnParesLetras";
            btnParesLetras.Size = new Size(233, 76);
            btnParesLetras.TabIndex = 3;
            btnParesLetras.Text = "Mesmo par de letras em sequência";
            btnParesLetras.UseVisualStyleBackColor = true;
            btnParesLetras.Click += btnParesLetras_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(486, 450);
            Controls.Add(btnParesLetras);
            Controls.Add(btnLetrasR);
            Controls.Add(btnEspacoBranco);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio1";
            Text = "Exercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnEspacoBranco;
        private Button btnLetrasR;
        private Button btnParesLetras;
    }
}