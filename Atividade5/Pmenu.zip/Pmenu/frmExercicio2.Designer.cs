﻿namespace Pmenu
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            btnInserir1 = new Button();
            btnCompara = new Button();
            btnInserir2 = new Button();
            SuspendLayout();
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Font = new Font("Segoe UI", 13F);
            lblPalavra1.Location = new Point(12, 9);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(77, 25);
            lblPalavra1.TabIndex = 0;
            lblPalavra1.Text = "Palavra1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Font = new Font("Segoe UI", 13F);
            lblPalavra2.Location = new Point(12, 94);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(82, 25);
            lblPalavra2.TabIndex = 1;
            lblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            txtPalavra1.Font = new Font("Segoe UI", 13F);
            txtPalavra1.Location = new Point(105, 9);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(100, 31);
            txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Font = new Font("Segoe UI", 13F);
            txtPalavra2.Location = new Point(105, 88);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(100, 31);
            txtPalavra2.TabIndex = 3;
            // 
            // btnInserir1
            // 
            btnInserir1.Font = new Font("Segoe UI", 13F);
            btnInserir1.Location = new Point(345, 9);
            btnInserir1.Name = "btnInserir1";
            btnInserir1.Size = new Size(110, 112);
            btnInserir1.TabIndex = 4;
            btnInserir1.Text = "Inserir 1º no meio do 2º";
            btnInserir1.UseVisualStyleBackColor = true;
            // 
            // btnCompara
            // 
            btnCompara.Font = new Font("Segoe UI", 13F);
            btnCompara.Location = new Point(229, 9);
            btnCompara.Name = "btnCompara";
            btnCompara.Size = new Size(110, 112);
            btnCompara.TabIndex = 5;
            btnCompara.Text = "Compara iguais";
            btnCompara.UseVisualStyleBackColor = true;
            btnCompara.Click += btnCompara_Click;
            // 
            // btnInserir2
            // 
            btnInserir2.Font = new Font("Segoe UI", 13F);
            btnInserir2.Location = new Point(461, 9);
            btnInserir2.Name = "btnInserir2";
            btnInserir2.Size = new Size(110, 112);
            btnInserir2.TabIndex = 6;
            btnInserir2.Text = "Inserir 2º asteriscos no meio do 1º";
            btnInserir2.UseVisualStyleBackColor = true;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(578, 133);
            Controls.Add(btnInserir2);
            Controls.Add(btnCompara);
            Controls.Add(btnInserir1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Name = "frmExercicio2";
            Text = "Formulário 2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPalavra1;
        private Label lblPalavra2;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button btnInserir1;
        private Button btnCompara;
        private Button btnInserir2;
    }
}