﻿namespace Pmenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtTexto = new RichTextBox();
            btnQtdNum = new Button();
            btnWhiteSpace = new Button();
            btnQtdAlfa = new Button();
            SuspendLayout();
            // 
            // rchtxtTexto
            // 
            rchtxtTexto.Location = new Point(16, 17);
            rchtxtTexto.Name = "rchtxtTexto";
            rchtxtTexto.Size = new Size(174, 174);
            rchtxtTexto.TabIndex = 0;
            rchtxtTexto.Text = "";
            // 
            // btnQtdNum
            // 
            btnQtdNum.Font = new Font("Segoe UI", 12F);
            btnQtdNum.Location = new Point(196, 17);
            btnQtdNum.Name = "btnQtdNum";
            btnQtdNum.Size = new Size(120, 174);
            btnQtdNum.TabIndex = 1;
            btnQtdNum.Text = "Quantidade caracteres numéricos";
            btnQtdNum.UseVisualStyleBackColor = true;
            btnQtdNum.Click += btnQtdNum_Click;
            // 
            // btnWhiteSpace
            // 
            btnWhiteSpace.Font = new Font("Segoe UI", 12F);
            btnWhiteSpace.Location = new Point(322, 17);
            btnWhiteSpace.Name = "btnWhiteSpace";
            btnWhiteSpace.Size = new Size(120, 174);
            btnWhiteSpace.TabIndex = 2;
            btnWhiteSpace.Text = "Localizar do primeiro whitespace";
            btnWhiteSpace.UseVisualStyleBackColor = true;
            btnWhiteSpace.Click += btnWhiteSpace_Click;
            // 
            // btnQtdAlfa
            // 
            btnQtdAlfa.Font = new Font("Segoe UI", 12F);
            btnQtdAlfa.Location = new Point(448, 17);
            btnQtdAlfa.Name = "btnQtdAlfa";
            btnQtdAlfa.Size = new Size(120, 174);
            btnQtdAlfa.TabIndex = 3;
            btnQtdAlfa.Text = "Quantidade de caracteres alfabéticos";
            btnQtdAlfa.UseVisualStyleBackColor = true;
            btnQtdAlfa.Click += btnQtdAlfa_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(584, 211);
            Controls.Add(btnQtdAlfa);
            Controls.Add(btnWhiteSpace);
            Controls.Add(btnQtdNum);
            Controls.Add(rchtxtTexto);
            Name = "frmExercicio4";
            Text = "Formulário 4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtTexto;
        private Button btnQtdNum;
        private Button btnWhiteSpace;
        private Button btnQtdAlfa;
    }
}