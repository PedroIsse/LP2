namespace Pmenu
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou op��o copiar!", "Informa��o", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou op��o colar!", "Informa��o", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sa�da", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                MessageBox.Show("Form j� existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                frmExercicio3 frmExercicio3 = new frmExercicio3();
                frmExercicio3.MdiParent = this;
                frmExercicio3.WindowState = FormWindowState.Maximized;
                frmExercicio3.Show();
            }
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form j� existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.OpenForms["frmExercicio4"].Activate();
            }
            else
            {
                frmExercicio4 frmExercicio4 = new frmExercicio4();
                frmExercicio4.MdiParent = this;
                frmExercicio4.WindowState = FormWindowState.Maximized;
                frmExercicio4.Show();
            }
        }

        private void exerc�cio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form j� existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.OpenForms["frmExercicio5"].Activate();
            }
            else
            {
                frmExercicio5 frmExercicio5 = new frmExercicio5();
                frmExercicio5.MdiParent = this;
                frmExercicio5.WindowState = FormWindowState.Maximized;
                frmExercicio5.Show();
            }
        }

        private void exercicio2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                MessageBox.Show("Form j� existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercicio2 frmExercicio2 = new frmExercicio2();
                frmExercicio2.MdiParent = this;
                frmExercicio2.WindowState = FormWindowState.Maximized;
                frmExercicio2.Show();
            }
        }
    }
}
