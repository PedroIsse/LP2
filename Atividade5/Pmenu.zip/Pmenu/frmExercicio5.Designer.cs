﻿namespace Pmenu
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSortear = new Button();
            txtNum2 = new TextBox();
            txtNum1 = new TextBox();
            lblNum2 = new Label();
            lblNum1 = new Label();
            SuspendLayout();
            // 
            // btnSortear
            // 
            btnSortear.Font = new Font("Segoe UI", 13F);
            btnSortear.Location = new Point(227, 12);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(110, 112);
            btnSortear.TabIndex = 10;
            btnSortear.Text = "Sortear número";
            btnSortear.UseVisualStyleBackColor = true;
            // 
            // txtNum2
            // 
            txtNum2.Font = new Font("Segoe UI", 13F);
            txtNum2.Location = new Point(103, 91);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(100, 31);
            txtNum2.TabIndex = 9;
            // 
            // txtNum1
            // 
            txtNum1.Font = new Font("Segoe UI", 13F);
            txtNum1.Location = new Point(103, 12);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(100, 31);
            txtNum1.TabIndex = 8;
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Font = new Font("Segoe UI", 13F);
            lblNum2.Location = new Point(5, 97);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(92, 25);
            lblNum2.TabIndex = 7;
            lblNum2.Text = "Número 2";
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Font = new Font("Segoe UI", 13F);
            lblNum1.Location = new Point(5, 18);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(92, 25);
            lblNum1.TabIndex = 6;
            lblNum1.Text = "Número 1";
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(365, 141);
            Controls.Add(btnSortear);
            Controls.Add(txtNum2);
            Controls.Add(txtNum1);
            Controls.Add(lblNum2);
            Controls.Add(lblNum1);
            Name = "frmExercicio5";
            Text = "Formulário 5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSortear;
        private TextBox txtNum2;
        private TextBox txtNum1;
        private Label lblNum2;
        private Label lblNum1;
    }
}