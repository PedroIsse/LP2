﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdNum_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtTexto.Text.Length, cont = 0, qtdeNum = 0;

            while (cont < tamanho)
            {

                if (char.IsNumber(rchtxtTexto.Text[cont]))
                    qtdeNum++;

                cont++;
            }

            MessageBox.Show($"Quantidade de número: {qtdeNum}", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnWhiteSpace_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtTexto.Text.Length, posicao = 0;

            for (int i = 0; i < tamanho; i++)
            {
                if (char.IsWhiteSpace(rchtxtTexto.Text[i]))
                    posicao = i; break;
            }

            MessageBox.Show($"Posição do primeiro whitespace: {posicao}", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnQtdAlfa_Click(object sender, EventArgs e)
        {
            int qtdeLetras = 0;

            foreach(char c in rchtxtTexto.Text)
            {
                if (char.IsLetter(c))
                {
                    qtdeLetras++;
                }
            }

            MessageBox.Show($"Quantidade de letras: {qtdeLetras}", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
