using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite um n�mero: ", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    i--;
                }
            }

            Array.Reverse(vetor);

            aux = "";

            foreach (var i in vetor)
            {
                aux += i + "\n";
            }

            MessageBox.Show(aux, "Vetor:", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList() { "Ana", "Andr�", "D�bora", "F�tima", "Jo�o", "Janete", "Ot�vio", "Marcelo", "Pedro", "Thais" };

            listaAlunos.Remove("Ot�vio");

            string aux = "";

            foreach (var i in listaAlunos)
            {
                aux += i + "\n";
            }

            MessageBox.Show(aux, "Lista de Alunos:", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux;
            double media = 0;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a {i + 1} nota: ", "Entrada de dados");

                    if (!double.TryParse(aux, out notas[i, j]))
                    {
                        MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        j--;
                    }
                }
            }

            aux = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    media += notas[i, j];
                }

                media = media / 3;

                aux += $"Aluno {i + 1}: m�dia: " + media + "\n";

                media = 0;
            }

            MessageBox.Show(aux, "M�dia dos Alunos:", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExercio4_Click(object sender, EventArgs e)  // POR CONTA DE UM ENGANO, O FORMUL�RIO 4 POSSUI O EXERC�CIO 5, POR ISSO O BOT�O 4 CHAMA O FORM 5
        {
            frmExercicio5 frm5 = new frmExercicio5();
            frm5.Show();
        }

        private void btnExercicio5_Click_1(object sender, EventArgs e)// POR CONTA DE UM ENGANO, O FORMUL�RIO 5 POSSUI O EXERC�CIO 4, POR ISSO O BOT�O 5 CHAMA O FORM 4
        {
            frmExercicio4 frm4 = new frmExercicio4();
            frm4.Show();
        }
    }
}
