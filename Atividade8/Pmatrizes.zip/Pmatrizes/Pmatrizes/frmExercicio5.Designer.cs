﻿namespace Pmatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExecutar = new Button();
            lboxNomes = new ListBox();
            SuspendLayout();
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(12, 12);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(149, 424);
            btnExecutar.TabIndex = 0;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // lboxNomes
            // 
            lboxNomes.FormattingEnabled = true;
            lboxNomes.ItemHeight = 15;
            lboxNomes.Location = new Point(167, 12);
            lboxNomes.Name = "lboxNomes";
            lboxNomes.Size = new Size(548, 424);
            lboxNomes.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(727, 450);
            Controls.Add(lboxNomes);
            Controls.Add(btnExecutar);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExecutar;
        private ListBox lboxNomes;
    }
}