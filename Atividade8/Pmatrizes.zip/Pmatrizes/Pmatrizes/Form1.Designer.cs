﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExercicio1 = new Button();
            btnExercicio2 = new Button();
            btnExercicio3 = new Button();
            btnExercio4 = new Button();
            btnExercicio5 = new Button();
            SuspendLayout();
            // 
            // btnExercicio1
            // 
            btnExercicio1.Font = new Font("Segoe UI", 12F);
            btnExercicio1.Location = new Point(12, 12);
            btnExercicio1.Name = "btnExercicio1";
            btnExercicio1.Size = new Size(102, 76);
            btnExercicio1.TabIndex = 0;
            btnExercicio1.Text = "Exercício 1";
            btnExercicio1.UseVisualStyleBackColor = true;
            btnExercicio1.Click += btnExercicio1_Click;
            // 
            // btnExercicio2
            // 
            btnExercicio2.Font = new Font("Segoe UI", 12F);
            btnExercicio2.Location = new Point(120, 12);
            btnExercicio2.Name = "btnExercicio2";
            btnExercicio2.Size = new Size(102, 76);
            btnExercicio2.TabIndex = 1;
            btnExercicio2.Text = "Exercício 2";
            btnExercicio2.UseVisualStyleBackColor = true;
            btnExercicio2.Click += btnExercicio2_Click;
            // 
            // btnExercicio3
            // 
            btnExercicio3.Font = new Font("Segoe UI", 12F);
            btnExercicio3.Location = new Point(228, 12);
            btnExercicio3.Name = "btnExercicio3";
            btnExercicio3.Size = new Size(102, 76);
            btnExercicio3.TabIndex = 2;
            btnExercicio3.Text = "Exercício 3";
            btnExercicio3.UseVisualStyleBackColor = true;
            btnExercicio3.Click += btnExercicio3_Click;
            // 
            // btnExercio4
            // 
            btnExercio4.Font = new Font("Segoe UI", 12F);
            btnExercio4.Location = new Point(336, 12);
            btnExercio4.Name = "btnExercio4";
            btnExercio4.Size = new Size(102, 76);
            btnExercio4.TabIndex = 3;
            btnExercio4.Text = "Exercício 4";
            btnExercio4.UseVisualStyleBackColor = true;
            btnExercio4.Click += btnExercio4_Click;
            // 
            // btnExercicio5
            // 
            btnExercicio5.Font = new Font("Segoe UI", 12F);
            btnExercicio5.Location = new Point(444, 12);
            btnExercicio5.Name = "btnExercicio5";
            btnExercicio5.Size = new Size(102, 76);
            btnExercicio5.TabIndex = 4;
            btnExercicio5.Text = "Exercício 5";
            btnExercicio5.UseVisualStyleBackColor = true;
            btnExercicio5.Click += btnExercicio5_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(563, 104);
            Controls.Add(btnExercicio5);
            Controls.Add(btnExercio4);
            Controls.Add(btnExercicio3);
            Controls.Add(btnExercicio2);
            Controls.Add(btnExercicio1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExercicio1;
        private Button btnExercicio2;
        private Button btnExercicio3;
        private Button btnExercio4;
        private Button btnExercicio5;
    }
}
