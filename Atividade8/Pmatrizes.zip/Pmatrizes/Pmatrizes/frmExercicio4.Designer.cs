﻿namespace Pmatrizes
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lboxGabarito = new ListBox();
            btnVerificar = new Button();
            SuspendLayout();
            // 
            // lboxGabarito
            // 
            lboxGabarito.FormattingEnabled = true;
            lboxGabarito.ItemHeight = 15;
            lboxGabarito.Location = new Point(165, 12);
            lboxGabarito.Name = "lboxGabarito";
            lboxGabarito.Size = new Size(432, 424);
            lboxGabarito.TabIndex = 3;
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(10, 12);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(149, 424);
            btnVerificar.TabIndex = 2;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(609, 450);
            Controls.Add(lboxGabarito);
            Controls.Add(btnVerificar);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private ListBox lboxGabarito;
        private Button btnVerificar;
    }
}