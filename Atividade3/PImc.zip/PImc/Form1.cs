using System.Diagnostics.Eventing.Reader;
using System.Security.Cryptography.X509Certificates;

namespace PImc
{
    public partial class Form1 : Form
    {
        public double peso = 0, altura = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                mskbxPeso.Focus();
            }
            else
            {
                if (peso < 0)
                {
                    MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mskbxPeso.Focus();
                }
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                mskbxAltura.Focus();
            }
            else
            {
                if (altura < 0)
                {
                    MessageBox.Show("N�mero inv�lido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mskbxAltura.Focus();
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc = peso / (Math.Pow(altura, 2));

            imc = Math.Round(imc, 1);

            txtImc.Text = imc.ToString();

            if (imc > 40)
                MessageBox.Show("Obesidade Grave!", "IMC", MessageBoxButtons.OK);
            else if (imc >= 30)
                    MessageBox.Show("Obesidade!", "IMC", MessageBoxButtons.OK);
            else if (imc >= 25)
                    MessageBox.Show("Sobrepreso!", "IMC", MessageBoxButtons.OK);
            else if (imc >= 18.5)
                    MessageBox.Show("Normal!", "IMC", MessageBoxButtons.OK);
            else
                MessageBox.Show("Magreza!", "IMC", MessageBoxButtons.OK);
        }
    }
}
