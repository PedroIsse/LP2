﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblImc = new Label();
            lblAltura = new Label();
            btnSair = new Button();
            btnLimpar = new Button();
            btnCalcular = new Button();
            mskbxAltura = new MaskedTextBox();
            mskbxPeso = new MaskedTextBox();
            txtImc = new TextBox();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Font = new Font("Segoe UI", 15F);
            lblPeso.Location = new Point(0, 9);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(103, 28);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso Atual";
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Font = new Font("Segoe UI", 15F);
            lblImc.Location = new Point(0, 87);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(47, 28);
            lblImc.TabIndex = 1;
            lblImc.Text = "IMC";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Font = new Font("Segoe UI", 15F);
            lblAltura.Location = new Point(0, 49);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(65, 28);
            lblAltura.TabIndex = 2;
            lblAltura.Text = "Altura";
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 15F);
            btnSair.Location = new Point(548, 12);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(128, 50);
            btnSair.TabIndex = 3;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 15F);
            btnLimpar.Location = new Point(414, 12);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(128, 50);
            btnLimpar.TabIndex = 4;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 15F);
            btnCalcular.Location = new Point(280, 12);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(128, 50);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Font = new Font("Segoe UI", 12F);
            mskbxAltura.Location = new Point(130, 48);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(100, 29);
            mskbxAltura.TabIndex = 6;
            mskbxAltura.Validated += mskbxAltura_Validated;
            // 
            // mskbxPeso
            // 
            mskbxPeso.Font = new Font("Segoe UI", 12F);
            mskbxPeso.Location = new Point(130, 8);
            mskbxPeso.Mask = "900.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(100, 29);
            mskbxPeso.TabIndex = 7;
            mskbxPeso.Validated += mskbxPeso_Validated;
            // 
            // txtImc
            // 
            txtImc.Enabled = false;
            txtImc.Font = new Font("Segoe UI", 12F);
            txtImc.Location = new Point(130, 86);
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(100, 29);
            txtImc.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(686, 139);
            Controls.Add(txtImc);
            Controls.Add(mskbxPeso);
            Controls.Add(mskbxAltura);
            Controls.Add(btnCalcular);
            Controls.Add(btnLimpar);
            Controls.Add(btnSair);
            Controls.Add(lblAltura);
            Controls.Add(lblImc);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblImc;
        private Label lblAltura;
        private Button btnSair;
        private Button btnLimpar;
        private Button btnCalcular;
        private MaskedTextBox mskbxAltura;
        private MaskedTextBox mskbxPeso;
        private TextBox txtImc;
    }
}
